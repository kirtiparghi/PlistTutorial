//
//  ProductVC.swift
//  PlistDemo
//
//  Created by Kirti Parghi on 10/19/17.
//  Copyright © 2017 Kirti Parghi. All rights reserved.
//

import UIKit

class ProductVC: UIViewController {

    @IBOutlet weak var txtFieldProductPrice: UITextField!
    @IBOutlet weak var txtFieldProductName: UITextField!
    @IBOutlet weak var txtFieldProductID: UITextField!
    
    // VIEW LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()        
    }
    
    //Action --- ADD PRODUCT
    @IBAction func btnAddProductTapped(_ sender: UIButton) {
        var array = NSMutableArray()
        
        var paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) as Array
        let documentPath = paths[0] as String
        let path = documentPath.appending("ProductPlist")
        
        let fileManager = FileManager.default
        
        if !fileManager.fileExists(atPath: path) {
            if let bundlePath = Bundle.main.path(forResource: "ProductPlist", ofType: "plist") {
                array = NSMutableArray(contentsOfFile: bundlePath)!
                do {
                    try fileManager.copyItem(at: URL(fileURLWithPath: bundlePath), to: URL(fileURLWithPath: path))
                } catch {
                    print("copy failure")
                }
                
                let dictProduct = NSMutableDictionary()
                dictProduct["productid"] = txtFieldProductID.text
                dictProduct["productname"] = txtFieldProductName.text
                dictProduct["productprice"] = txtFieldProductPrice.text
                
                array.add(dictProduct)
                array.write(toFile: path, atomically: true)
                
                showMessage()
            }
            else {
                print("product plist not found")
            }
        }
        else {
            print("file product plist already exist at path")
            
            array = NSMutableArray(contentsOfFile: path)!
                        
            let dictProduct = NSMutableDictionary()
            dictProduct["productid"] = txtFieldProductID.text
            dictProduct["productname"] = txtFieldProductName.text
            dictProduct["productprice"] = txtFieldProductPrice.text
            
            array.add(dictProduct)
            array.write(toFile: path, atomically: true)
            
            showMessage()
        }
    }
    
    func showMessage() {
        let alrt = UIAlertController(title: "Message", message: "Product is added sucessfully.", preferredStyle: .alert)
        alrt.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (action) in
            alrt.dismiss(animated: true, completion: nil)
        }))
        self.present(alrt, animated: true, completion: nil)
    }
    
    //Action --- LIST PRODUCTS
    @IBAction func btnListProductsTapped(_ sender: UIButton) {
        self.performSegue(withIdentifier: "productlistSegue", sender: self)
    }

    // MEMORY MANAGEMENT
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
